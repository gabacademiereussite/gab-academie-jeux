# Quiz Conjugaison CM2

1. Ajoutez `index.html` dans un dépôt GitHub.
2. Activez GitHub Pages : Settings > Pages > Deploy from a branch > main > /root.
3. Copiez l'URL GitHub Pages.
4. Intégrez-la dans votre site avec une iframe.

Le quiz comporte 20 questions : présent, imparfait, futur simple et passé composé.
